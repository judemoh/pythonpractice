from replit import clear
#HINT: You can call clear() to clear the output in the console.
from art import logo
print(logo)
bids = {}
def add_bidder(bidder, bidprice):
  bids[name] = price
anotherbidder = True
while anotherbidder == True:
  name = input("What is your name")
  price = input("What is your bid")
  add_bidder(name, price)
  anotherbid = input("is there another bidder?")
  if anotherbid == "yes":
    clear() 
  elif anotherbid == "no":
    anotherbidder = False
    max_key = max(bids,key=bids.get)
    print(f"The winner of the bid is {max_key}")
  
    
    

  
  