def add(n1, n2):
  return n1+n2
def subtract(n1, n2):
  return n1-n2
def multiply(n1, n2):
  return n1*n2
def divide(n1, n2):
  return n1/n2
#create a dictionary where the keys are the operations and values are the names of the functions
operations = {
"+": add,
  "-": subtract,
  "*": multiply,
  "/": divide
}
from art import logo
print(logo)
def calculator():
  continue_calc = True
  while continue_calc:
    num1 = float(input('what is the first number'))
    for op in operations:
      print(op)
    operation_symbol =input("Pick an operation from the line above")
    if operation_symbol not in operations:
      print("This is not a valid operation.")
      raise KeyError("this is not a valid operation")
    num2 = float(input('what is the second number')) #gives a better user experiencee
    answer = operations[operation_symbol]
    solution = answer(num1, num2)
    print(f"{num1} {operation_symbol} {num2} = {solution}")
    continue_input = input("Would you like to continue? enter y for yes to continue and no for a new calculation")
    if continue_input == 'y':
      num1 = answer
    elif continue_input == 'n':
      continue_calc = False
      print('Goodbye')
      calculator() #make sure that when youre calling a function within itself that there are conditions for it to meet in order to continue
  
calculator()

    
    
